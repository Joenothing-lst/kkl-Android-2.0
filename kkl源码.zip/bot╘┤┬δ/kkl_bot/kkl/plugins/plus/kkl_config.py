# -*- coding:utf-8 -*-
master=[912871833]#主人,第一个填自己
manager=[]+master#词库管理员
jjc_key=''#网站作者提供的key，用于绕过验证，作者qq：196435005