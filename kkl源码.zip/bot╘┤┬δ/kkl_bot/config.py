# -*- coding:utf-8 -*-
from nonebot.default_config import *

COMMAND_START = {'/', '!', '／', '！',''}
NICKNAME = {'妈','可可萝'}